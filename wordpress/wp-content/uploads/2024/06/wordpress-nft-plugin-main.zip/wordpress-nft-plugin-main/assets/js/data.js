const TestNetContract = "0xE7dd1252f50B3d845590Da0c5eADd985049a03ce"
const MainNetContract = "0xE468cE99444174Bd3bBBEd09209577d25D1ad673"
const TestNft = "0xadf9b34b82de3ef70bb943db659791f44e65af4a";
const defaultCurrator = "0x79FD2F15e0EA8C27b5192259F9da63f4E562f021";
const MirrorContract = "";
const EthAdd = "0x0000000000000000000000000000000000000000";
const CustomContract = "0x13aBD028C6C4eB661F69590ddAFC4d956E23889A";

const rpc = ""